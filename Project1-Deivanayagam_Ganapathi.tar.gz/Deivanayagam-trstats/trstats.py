import argparse
import json
import re
import statistics
import subprocess
import sys
import plotly.express as px # type: ignore

def run_traceroute(target, attempts):
    all_hops = {}
    for _ in range(attempts):
        result = subprocess.run(['traceroute', target], stdout=subprocess.PIPE)
        output = result.stdout.decode()
        for line in output.split('\n'):
            match = re.match(r"(\d+)\s+(\S+)\s+\(([\d\.]+)\)\s+([\d\.]+)\s+ms", line)
            if match:
                hop = int(match.group(1))
                ip = match.group(2)
                latency = float(match.group(4))
                if hop not in all_hops:
                    all_hops[hop] = {'latencies': [], 'hosts': set()}
                all_hops[hop]['latencies'].append(latency)
                all_hops[hop]['hosts'].add(ip)
    return all_hops

def run_ping(target, count):
    rtts = []
    for _ in range(count):
        result = subprocess.run(['ping', '-c', '1', target], stdout=subprocess.PIPE)
        output = result.stdout.decode()
        match = re.search(r'time=(\d+\.\d+) ms', output)
        if match:
            rtts.append(float(match.group(1)))
    return rtts

def calculate_statistics(latencies):
    stats = {
        'avg': round(statistics.mean(latencies), 3) if latencies else 0,
        'med': round(statistics.median(latencies), 3) if latencies else 0,
        'min': round(min(latencies), 3) if latencies else 0,
        'max': round(max(latencies), 3) if latencies else 0
    }
    return stats

def plot_boxplot(data, title):
    labels = [f'Hop {hop}' for hop in data for _ in range(len(data[hop]['latencies']))]
    latencies = [latency for hop in data for latency in data[hop]['latencies']]
    fig = px.box(x=labels, y=latencies, title=title)
    fig.update_layout(xaxis_title="Hop", yaxis_title="Latency (ms)")
    fig.show()

def main(args):
    if args.traceroute:
        hops = run_traceroute(args.traceroute, args.count)
        for hop in hops:
            hops[hop]['hosts'] = list(hops[hop]['hosts'])
            hops[hop].update(calculate_statistics(hops[hop]['latencies']))
        print(json.dumps(hops, indent=2))
        plot_boxplot(hops, "Traceroute Latency Distribution")
    elif args.ping:
        rtts = run_ping(args.ping, args.count)
        ping_stats = calculate_statistics(rtts)
        print(json.dumps(ping_stats, indent=2))
        plot_boxplot({'Ping': {'latencies': rtts}}, "Ping RTT Distribution")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Network Diagnostic Tool")
    parser.add_argument("--traceroute", help="Perform a traceroute to the target")
    parser.add_argument("--ping", help="Perform a ping to the target")
    parser.add_argument("--count", type=int, default=3, help="Number of times to execute the command")
    args = parser.parse_args()
    main(args)
