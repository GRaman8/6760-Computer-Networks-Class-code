import argparse
import json
import re
import statistics
import subprocess
import sys
import os
import plotly.express as px
import plotly.io as pio

def run_traceroute(target, attempts):
    all_hops = {}
    for _ in range(attempts):
        result = subprocess.run(['traceroute', target], stdout=subprocess.PIPE)
        output = result.stdout.decode()
        for line in output.split('\n'):
            match = re.match(r"(\d+)\s+(\S+)\s+\(([\d\.]+)\)\s+([\d\.]+)\s+ms", line)
            if match:
                hop = int(match.group(1))
                ip = match.group(2)
                latency = float(match.group(4))
                if hop not in all_hops:
                    all_hops[hop] = {'latencies': [], 'hosts': set()}
                all_hops[hop]['latencies'].append(latency)
                all_hops[hop]['hosts'].add(ip)
    return all_hops

def run_ping(target, count):
    rtts = []
    for _ in range(count):
        result = subprocess.run(['ping', '-c', '1', target], stdout=subprocess.PIPE)
        output = result.stdout.decode()
        match = re.search(r'time=(\d+\.\d+) ms', output)
        if match:
            rtts.append(float(match.group(1)))
    return rtts

def calculate_statistics(latencies):
    stats = {
        'avg': round(statistics.mean(latencies), 3) if latencies else 0,
        'med': round(statistics.median(latencies), 3) if latencies else 0,
        'min': round(min(latencies), 3) if latencies else 0,
        'max': round(max(latencies), 3) if latencies else 0
    }
    return stats

def plot_boxplot(data, title, output_graph):
    labels = []
    latencies = []
    
    # Make sure to correctly structure the data
    for hop, hop_data in data.items():
        if 'latencies' in hop_data and len(hop_data['latencies']) > 0:
            labels += [f'Hop {hop}'] * len(hop_data['latencies'])
            latencies += hop_data['latencies']
    
    # Debugging output to inspect the data before plotting
    print("Labels (Hops):", labels)
    print("Latencies (ms):", latencies)
    
    if len(labels) > 0 and len(latencies) > 0:
        # Generate the boxplot using Plotly
        fig = px.box(x=labels, y=latencies, title=title, labels={"x": "Hop", "y": "Latency (ms)"})
        
        # Save the graph as a PDF
        pio.write_image(fig, output_graph)
    else:
        print("No data to plot.")

def process_test_file(test_dir):
    all_hops = {}
    try:
        # Iterate over each file in the test directory
        for filename in os.listdir(test_dir):
            file_path = os.path.join(test_dir, filename)
            print(f"Processing file: {file_path}")
            
            with open(file_path, 'r') as f:
                output = f.read()

                # Parse the output of each file
                for line in output.split('\n'):
                    match = re.match(r"(\d+)\s+(\S+)\s+\(([\d\.]+)\)\s+([\d\.]+)\s+ms", line)
                    if match:
                        hop = int(match.group(1))
                        ip = match.group(2)
                        latency = float(match.group(4))
                        if hop not in all_hops:
                            all_hops[hop] = {'latencies': [], 'hosts': set()}
                        all_hops[hop]['latencies'].append(latency)
                        all_hops[hop]['hosts'].add(ip)
        
        # Convert sets to lists before returning the result
        for hop in all_hops:
            all_hops[hop]['hosts'] = list(all_hops[hop]['hosts'])
        
        return all_hops
    except Exception as e:
        print(f"Error processing file {test_dir}: {e}")
        return {}

def main():
    parser = argparse.ArgumentParser(description="Network Diagnostic Tool")
    parser.add_argument("--test", help="Path to the test files directory")
    parser.add_argument("-n", type=int, help="Number of times traceroute will run")
    parser.add_argument("-d", type=int, help="Number of seconds to wait between consecutive runs")
    parser.add_argument("-m", type=int, help="Number of max hops per traceroute run")
    parser.add_argument("--traceroute", help="Perform a traceroute to the target")
    parser.add_argument("--ping", help="Perform a ping to the target")
    parser.add_argument("-p", type=int, help="Number of ping packets to send")
    parser.add_argument("-pd", type=int, help="Number of seconds to wait between ping packets")
    parser.add_argument("-o", "--output", help="Output JSON file")
    parser.add_argument("-g", "--graph", help="Output graph file (PDF)")
    
    args = parser.parse_args()

    if args.test:
        data = process_test_file(args.test)
    elif args.traceroute:
        hops = run_traceroute(args.traceroute, args.n)
        for hop in hops:
            # Convert the set to a list for JSON serialization
            hops[hop]['hosts'] = list(hops[hop]['hosts'])
            hops[hop].update(calculate_statistics(hops[hop]['latencies']))
        data = hops
    elif args.ping:
        rtts = run_ping(args.ping, args.p)
        data = {'Ping': {'latencies': rtts}}
        data['Ping'].update(calculate_statistics(rtts))
    else:
        print("No valid target provided. Use --target, --ping, or --test.")
        sys.exit(1)

    # Output JSON to file if specified
    if args.output:
        with open(args.output, 'w') as json_file:
            json.dump(data, json_file, indent=2)
        print(f"Results saved to {args.output}")
    
    # Output graph to file if specified
    if args.graph:
        plot_boxplot(data, "Latency Distribution", args.graph)
        print(f"Graph saved to {args.graph}")

if __name__ == "__main__":
    main()
