#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <pthread.h>
#include <openssl/ssl.h>
#include <openssl/err.h>
#include <arpa/inet.h>
#include <netdb.h>

#define BUFFER_SIZE 8192

typedef struct {
    char *url;
    int part_index;
    int start_byte;
    int end_byte;
    char *output_file;
} download_task;

// Mutex for synchronizing file writing
pthread_mutex_t file_write_mutex;

void init_openssl() {
    SSL_load_error_strings();
    OpenSSL_add_ssl_algorithms();
}

void cleanup_openssl() {
    EVP_cleanup();
}

SSL_CTX *create_context() {
    const SSL_METHOD *method;
    SSL_CTX *ctx;

    method = TLS_client_method();
    ctx = SSL_CTX_new(method);
    if (!ctx) {
        perror("Unable to create SSL context");
        ERR_print_errors_fp(stderr);
        exit(EXIT_FAILURE);
    }

    return ctx;
}

// Function to download a file part or the entire file
void *download_part(void *arg) {
    download_task *task = (download_task *)arg;

    char host[256], path[1024];
    sscanf(task->url, "https://%[^/]%s", host, path);

    int port = 443;
    struct hostent *server = gethostbyname(host);
    if (server == NULL) {
        fprintf(stderr, "ERROR, no such host\n");
        return NULL;
    }

    SSL_CTX *ctx = create_context();
    SSL *ssl;

    // Create a socket
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("ERROR opening socket");
        return NULL;
    }

    // Set up the server address struct
    struct sockaddr_in serv_addr;
    memset(&serv_addr, 0, sizeof(serv_addr));
    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(port);
    memcpy(&serv_addr.sin_addr.s_addr, server->h_addr, server->h_length);

    // Connect to the server
    if (connect(sockfd, (struct sockaddr *)&serv_addr, sizeof(serv_addr)) < 0) {
        perror("ERROR connecting");
        return NULL;
    }

    // Establish SSL connection
    ssl = SSL_new(ctx);
    SSL_set_fd(ssl, sockfd);
    if (SSL_connect(ssl) <= 0) {
        ERR_print_errors_fp(stderr);
        return NULL;
    }

    printf("Connected to %s for part %d\n", host, task->part_index);

    // Send the GET request (ignoring range, we'll download everything)
    char request[2048];
    snprintf(request, sizeof(request), 
             "GET %s HTTP/1.1\r\nHost: %s\r\nConnection: close\r\n\r\n", path, host);

    printf("Sending GET request\n");

    SSL_write(ssl, request, strlen(request));

    // Open the output part file
    char part_filename[256];
    snprintf(part_filename, sizeof(part_filename), "%s_part_%d", task->output_file, task->part_index);
    FILE *part_file = fopen(part_filename, "wb");
    if (part_file == NULL) {
        perror("ERROR opening part file");
        return NULL;
    }

    // Read the response and write the data to the part file
    char buffer[BUFFER_SIZE];
    int bytes;
    int header_passed = 0;

    while ((bytes = SSL_read(ssl, buffer, sizeof(buffer))) > 0) {
        if (!header_passed) {
            // Skip headers
            char *header_end = strstr(buffer, "\r\n\r\n");
            if (header_end) {
                header_passed = 1;
                fwrite(header_end + 4, 1, bytes - (header_end - buffer) - 4, part_file);
            }
        } else {
            fwrite(buffer, 1, bytes, part_file);
        }
    }

    fclose(part_file);
    SSL_free(ssl);
    close(sockfd);
    SSL_CTX_free(ctx);

    printf("Finished downloading part %d\n", task->part_index);
    return NULL;
}

// Function to reassemble all parts into one final output file
void reassemble_parts(int num_parts, const char *output_file) {
    FILE *output = fopen(output_file, "wb");
    if (!output) {
        perror("Error opening output file");
        exit(EXIT_FAILURE);
    }

    for (int i = 0; i < num_parts; i++) {
        char part_filename[256];
        snprintf(part_filename, sizeof(part_filename), "%s_part_%d", output_file, i);

        FILE *part_file = fopen(part_filename, "rb");
        if (!part_file) {
            perror("Error opening part file");
            continue;
        }

        char buffer[BUFFER_SIZE];
        size_t bytes_read;
        while ((bytes_read = fread(buffer, 1, sizeof(buffer), part_file)) > 0) {
            fwrite(buffer, 1, bytes_read, output);
        }

        fclose(part_file);
    }

    fclose(output);
    printf("Reassembled all parts into %s\n", output_file);
}

int main(int argc, char *argv[]) {
    // Variables to store options
    char *url = NULL;
    int num_parts = 1;  // Default to 1 part if not specified
    char *output_file = NULL;
    int opt;

    // Parse command-line options using getopt
    while ((opt = getopt(argc, argv, "u:n:o:")) != -1) {
        switch (opt) {
            case 'u':
                url = optarg;
                break;
            case 'n':
                num_parts = atoi(optarg);
                break;
            case 'o':
                output_file = optarg;
                break;
            default:
                fprintf(stderr, "Usage: %s -u URL -n NUM_PARTS -o OUTPUT_FILE\n", argv[0]);
                exit(EXIT_FAILURE);
        }
    }

    if (url == NULL || num_parts <= 0 || output_file == NULL) {
        fprintf(stderr, "Usage: %s -u URL -n NUM_PARTS -o OUTPUT_FILE\n", argv[0]);
        exit(EXIT_FAILURE);
    }

    // Print a message about the parameters being used
    printf("n = %d, url = %s, outputfile = %s\n", num_parts, url, output_file);

    // Initialize OpenSSL and threading mutex
    init_openssl();
    pthread_mutex_init(&file_write_mutex, NULL);

    // Create download tasks for each part
    pthread_t threads[num_parts];
    download_task tasks[num_parts];

    for (int i = 0; i < num_parts; ++i) {
        tasks[i].url = url;
        tasks[i].part_index = i;
        tasks[i].output_file = output_file;
        pthread_create(&threads[i], NULL, download_part, &tasks[i]);
    }

    // Wait for all threads to finish
    for (int i = 0; i < num_parts; ++i) {
        pthread_join(threads[i], NULL);
    }

    // Reassemble the parts into the final output file
    reassemble_parts(num_parts, output_file);

    // Clean up
    pthread_mutex_destroy(&file_write_mutex);
    cleanup_openssl();

    printf("Download completed and parts reassembled.\n");
    return 0;
}
